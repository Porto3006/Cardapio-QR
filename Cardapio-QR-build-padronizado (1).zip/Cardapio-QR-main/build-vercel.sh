#!/usr/bin/env bash
# Script padrão de build na Vercel. Funciona com Root Directory "/" ou "frontend".
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$DIR/package.json" ]; then FRONT="$DIR"; else FRONT="$DIR/frontend"; fi
[ -f "$FRONT/package.json" ] || { echo "ERRO: package.json do frontend não encontrado"; exit 1; }
echo "==> Node $(node -v) / npm $(npm -v)"
echo "==> Frontend em: $FRONT"
cd "$FRONT"
export CI=false
echo "==> Instalando dependências"
npm install --no-audit --no-fund --legacy-peer-deps
echo "==> Gerando o site"
npm run build
[ -f "$FRONT/build/index.html" ] || { echo "ERRO: build/index.html não foi gerado"; exit 1; }
if [ "$FRONT" != "$DIR" ]; then rm -rf "$DIR/build"; cp -r "$FRONT/build" "$DIR/build"; fi
echo "==> Build concluído"
