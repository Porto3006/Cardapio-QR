#!/usr/bin/env bash
# Build do frontend para a Vercel (funciona com Root Directory "/" ou "frontend")
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$DIR/package.json" ]; then FRONT="$DIR"; else FRONT="$DIR/frontend"; fi
cd "$FRONT"
npm install --no-audit --no-fund --legacy-peer-deps
npm run build
# Se o Root Directory for a raiz, copia a saída para ./build
if [ "$FRONT" != "$DIR" ]; then rm -rf "$DIR/build"; cp -r "$FRONT/build" "$DIR/build"; fi
